import json
import re
from tqdm import tqdm
from openai import OpenAI
import random
# client = OpenAI(
#     api_key='EMPTY',
#     base_url='http://localhost:9692/v1',
# )
client = OpenAI(api_key="sk-167d0f65e8d14b37b7b48ebaa9319fa0", base_url="https://api.deepseek.com")
# model_type = client.models.list().data[0].id
model_type = "deepseek-chat"
json_file = "/workspace/xpj/code/swift/news_text_qwen_result_clean2_sft.json"

with open(json_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

result = []

for item in tqdm(data[:5000]):
    response = item['response']
    origin_context = item['query']
    original_string_str = ''.join(response)
    # 使用正则表达式匹配括号内的内容
    pattern = r'\((.*?)\)'
    matches = re.findall(pattern, original_string_str)
    # 对matches 进行去重
    matches = list(set(matches))
    # 如果某个元素是另一个的子集，则删除子集

    multi_match = []
    for match in matches:
        if len(match.split(',')) > 1:
            multi_match.append(match)
    if len(multi_match) > 2:
        multi_match =random.sample(multi_match, 1)
    for match in multi_match:
        for id in range(len(match.split(',')) -1):
            cur_result = {}
            try:
                entity_0 = match.split(',')[id]
                entity_1 = match.split(',')[id+1]

                query = f"{entity_0},{entity_1}:{origin_context}"

                messages = [
                    {"role": "system", "content":"You are a helpful assistant"},
                    {"role": "system", "content": "你是一个地理实体关系抽取专家，能够对涉及的地理实体准确抽取其上下文信息,并且需要判断地理实体AB之间的关系，并按照规定格式进行输出。具体的要求如下：\
                    1.我的输入包括:地理实体A,地理实体B,粗粒度的上下文信息。\
                    2.你需要根据地理实体A,B,粗粒度上下文信息,生成包含A,B的细粒度的上下文信息,生成的上下文信息一定包含地理实体A和B。并且A,B在上下文中各自仅出现一次,同时上下文不超过两句话。\
                    4.预测两个地理实体之间的关系，可供选择的关系有：隶属,并列 两种,请给出最有可能的关系。\
                    5.请按照：关系#上下文 的格式直接输出,不允许输出其他内容。"},
                    {"role": "user", "content": query}
                ]
                kwargs = {'model': model_type, 'messages': messages,'stream':False,'max_tokens': 512}
                resp = client.chat.completions.create(**kwargs)
                new_response = resp.choices[0].message.content
                relation = new_response.split('#')[0]
                context = new_response.split('#')[1]
                cur_result['entity_0'] = entity_0
                cur_result['entity_1'] = entity_1
                cur_result['relation'] = relation
                cur_result['context'] = context

                result.append(cur_result)
            except Exception as e:
                print(e)
                continue
            

with open("news_text_qwen_result_clean2_sft_relation_context_5000.json", 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=4)


