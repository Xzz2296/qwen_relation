# -*- coding: utf-8 -*-
import re
from typing import List, Optional

class TempoPromptGenerator:
    def __init__(self):
        self._ChineseReigns = "((中华)?民国|安[乐太]|白[龙雀]|颁义|宝[大鼎历庆胜太义应祐元贞正]|保[大定宁贞]|本[初始]|昌[平武]|奲都|成化|承[安道光和明平圣玄阳]|赤乌|崇[德福和宁庆祯]|初[平始元]|垂拱|淳[化熙祐]|大[安宝成乘德定观和亨康历明启庆圣顺通同统武象兴业有中足]|大中祥符|道光|德[昌兴祐]|地[皇节]|登国|调露|定鼎|端[拱平]|法轮|凤[凰历翔]|福圣(承道)?|复汉|甘露|庚子|更[始新兴]|拱化|光[初大定和化启庆始寿天熙熹兴绪宅]|广[安初大德明顺运政]|汉[安昌复兴]|和平|河[平清瑞]|黑龙|弘[昌道光始治]|宏昌|洪[武熙]|鸿嘉|后元|皇[初建庆始统兴祐]|黄[初龙武]|皇[初建庆始统兴祐]|黄[初龙武]|会[昌同]|嘉[定禾靖宁平庆泰熙兴祐]|建([安昌初德福光国和衡弘康隆明宁平始世文武熙兴炎义元昭贞中]|武中元|中靖国)|交泰|金统|进通|景[初德定福和龙明平泰炎耀祐元云]|竟宁|靖康|久视|居摄|开[宝成皇明平庆泰禧兴耀元运]|康[定国宁熙]|麟[德嘉]|六玺|龙[德飞纪启升朔兴]|隆[安昌和化庆武兴绪]|鲁兴|罗平|明[昌道德庆受政]|宁康|平[都赵]|普[嘉泰通兴]|乾[道德定封符和亨化隆明宁统兴祐元贞]|青龙|清[宁泰]|庆[历元]|人庆|仁寿|如意|上[元愿]|绍[定汉圣泰武熙兴]|神[册鼎凤功龟虎嘉䴥爵历龙平瑞上兽玺]|升[国明平元]|圣[君历明武]|胜光|盛昌|石平|(始建国((地皇|天凤)(上戊)?)?)|始[光建平兴元]|收国|寿[昌光]|顺[天义治]|朔宁|嗣圣|绥和|太([安昌初和极建康宁平清上始熙兴延元缘]|初元将|平(兴国|真君))|泰[昌常定和始豫]|唐[安隆兴元]|天(安礼定|册万岁|赐礼盛国庆|授礼法延祚|仪治平|[安宝保册成赐聪德凤福辅复汉和皇会纪嘉监建眷康历禄明命平启庆圣盛寿授顺统威玺禧显兴佑祐赞造正祚]|佑垂圣|祐(垂圣|民安))|通[文正]|同[光治]|统和|万历|万岁(登封|通天)|王霸|文[德明]|五凤|武[成德定平泰义]|熙[宁平]|熹平|先天|咸[安淳丰和亨康宁平清通熙雍]|显[道德庆圣]|祥兴|孝[昌基建]|兴[安定光和宁平元]|宣[德和平统政]|玄始|延[昌初光和康平庆寿熙熹兴祐载]|延嗣宁国|炎兴|晏平|燕[平兴元]|阳[嘉朔]|仪凤|义[和嘉宁熙]|应[历乾天]|雍[宁熙正]|永[安昌崇初淳定凤光汉和弘徽嘉建康乐历隆明宁平始寿泰熙熹憙新兴元贞]|玉[恒衡]|元[初德鼎丰封凤符光和徽嘉康平始寿受狩朔统熙玺象兴延祐贞]|缘禾|允光|载初|章[和武]|长[安乐庆寿兴]|昭宁|贞[观明祐元]|真[王兴]|祯明|征和|正[大德光隆明平始统元]|证圣|政和|至[成大道德和宁顺元正治平]|致和|中大同|中[和平统兴元]|中[元宗]克复|重[光和熙]|总章|佐初)"
        self._ChineseReignYear = "(元年|((([一二三四五六七八九]十?)|[〇零十廿卅])[一二三四五六七八九〇零]?|[０１２３４５６７８９]{1,3}|\\d{1,3})[年载])"
        self._ChristianYear = "(([一二][〇零一二三四五六七八九十百千]{3}|[1-2]\\d{3}|[１２][０１２３４５６７８９]{3}|([西公]元前?(元|[1-9]\\d*|[一二三四五六七八九十廿卅][〇零一二三四五六七八九十廿卅百千]*|[１２３４５６７８９][０１２３４５６７８９]*)))年|(?<![a-zA-Z])BC\\s*\\d{1,4}(?!\\d))"
        self.Century = "(?P<Century>(([一二]十?|十)?[〇零一二三四五六七八九]|[12]?\\d|[１２]?[０１２３４５６７８９])世纪)"
        self.Decade = "(?P<Decade>([〇零一二三四五六七八九]+[十〇零]|[廿卅]|[０１２３４５６７８９]+０|\\d+0)年代)"
        self.FiveYearPlan = "(?P<FiveYearPlan>([一二三四五六七八九]|十[一二三四五六七八九]?)五(计划|期间))"
        self.Year = f"(?P<Year>({self._ChineseReigns}{self._ChineseReignYear}|{self._ChristianYear}))"
        self.MaybeYear = "(?P<MaybeYear>((\\d+[-—~～﹣－到至])?\\d+|([〇零一二三四五六七八九十廿卅百千]+[-—~～﹣－到至])?[几〇零一二三四五六七八九十廿卅百千]+|([０１２３４５６７８９]+[-—~～﹣至])?[０１２３４５６７８９]+|元)[多]?年[度份]?)"
        self.Season = "(?P<Season>[春夏秋冬][季天]?|浅春|[初晚][春夏秋冬]|[早仲][春夏秋]|深[秋冬]|隆冬)"
        self.YearQuater = "(?P<YearQuater>[前后上下头]半年|最后一个?季度?|第[１２３４1-4一二三四]季度?|[１２３４1-4一二三四]季度)"
        self.Current = "(?P<Current>[目当]前]|[现当]代|[当现]?今|现在)"
        self.MonthTime = "(?P<MonthTime>[上中下]+旬)"
        self.Week = "(?P<Week>(星期|周|礼拜)[一二三四五六七日]|礼拜天|星期天|周末)"
        self.Holidy = "(?P<Holiday>(元旦|清明|中秋|端午|国庆|圣诞)节?|((六一)?儿童|(八一)?建军|教师|万圣|元宵|情人|(五四)?青年|妇女|愚人|(五一)?劳动)节)"
        self.YYYYMMDD = "(?P<YYYYMMDD>((?<!\\d)[1-9]\\d{1,3}((?P<S1>[-—~～﹣－\\/＼／])|年)(0?[1-9]|1[0-2])((?P=S1)|月)初?([0-2]?\\d|3[01])(?!\\d)[日]?|(?<![０１２３４５６７８９])[１２３４５６７８９][０１２３４５６７８９]{1,3}((?P<S2>[-—~～﹣－\\/＼／])|年)(０?[１２３４五六七八９]|１[０１２])((?P=S2)|月)初?([０１２][０１２３４５６７８９]|３[０１])(?![０１２３４５６７８９])[日]?|(?<![〇零一二三四五六七八九廿卅])([〇零一二三四五六七八九廿卅][千百十]?){1,4}年([〇零]?[一二三四五六七八九]|十|(一十?|十)[〇零一二])月初?(([〇零十廿]|[一二]十?)?[〇零一二三四五六七八九]|[十廿卅]|(三十?|卅)[〇零一])日))"

        self.YYYYMMDD = "(?P<YYYYMMDD>((?<!\\d)[1-9]\\d{1,3}((?P<S1>[-—~～﹣－\\/＼／])|年)(0?[1-9]|1[0-2])((?P=S1)|月)初?([0-2]?\\d|3[01])(?!\\d)[日]?|(?<![０１２３４５６７８９])[１２３４５６７８９][０１２３４５６７８９]{1,3}((?P<S2>[-—~～﹣－\\/＼／])|年)(０?[１２３４五六七八９]|１[０１２])((?P=S2)|月)初?([０１２][０１２３４５６７８９]|３[０１])(?![０１２３４５６７８９])[日]?|(?<![〇零一二三四五六七八九廿卅])([〇零一二三四五六七八九廿卅][千百十]?){1,4}年([〇零]?[一二三四五六七八九]|十|(一十?|十)[〇零一二])月初?(([〇零十廿]|[一二]十?)?[〇零一二三四五六七八九]|[十廿卅]|(三十?|卅)[〇零一])日))"

        self.MMDDYYYY = "(?P<MMDDYYYY>(?<!\\d)(0?[1-9]|1[0-2])(?P<S3>[-—~～﹣－\\/＼／])([0-2]?\\d|3[01])(?P=S3)[1-9]\\d{1,3}(?!\\d)|(?<![０１２３４５６７８９])(０?[１２３４五六七八９]|１[０１２])(?P<S4>[-—~～﹣－\\/＼／])([０１２][０１２３４５６７８９]|３[０１])(?P=S4)[１２３４５６７８９][０１２３４５６７８９]{1,3}(?![０１２３４５６７８９]))"
        self.HHMMSS = "(?P<HHMMSS>((?<!\\d)([01]?\\d|2[0-4])((?P<S5>[:：])|时)([0-5]?\\d|60)((?P=S5)([0-5]?\\d|60)(?!\\d)|分(([0-5]?\\d|60)秒)?)|(?<![０１２３４５６７８９])([０１]?[０１２３４５６７８９]|２[０１２３４])(?P<S6>[:：]|时)([０１２３４５]?[０１２３４５６７８９]|６０)((?P=S6)([０１２３４５]?[０１２３４５６７８９]|６０)(?![０１２３４５６７８９])|分(([０１２３４５]?[０１２３４５６７８９]|６０)秒)?)|(?<![〇零一二三四五六七八九十廿卅百千万])((一十?|[〇零十])?[〇零一二三四五六七八九]|[十廿]|(二十?|廿)[〇零一二三四])时((一二三四五]十?|[〇零十廿卅])?[〇零一二三四五六七八九]|[十廿卅]|六[〇零十])分(((|一二三四五]十?|[〇零十廿卅])?[〇零一二三四五六七八九]|[十廿卅]|六[〇零十])秒)?))"
        self.MaybeMonth = "(?P<MaybeMonth>((\\d{1,2}[-—~～﹣－到至])?\\d{1,2}|([〇零一二三四五六七八九十]+[-—~～﹣－到至])?[几〇零一二三四五六七八九十]+|([０１２３４５６７８９]{1,2}[-—~～﹣－到至])?[０１２３４５６７８９]{1,2})[个]?月份?|[正腊]月)"
        self.MaybeDay = "(?P<MaybeDay>((\\d+[-—~～﹣－到至])?\\d+|(初?[〇零一二三四五六七八九十廿卅百千]+[-—~～﹣－到至])?初?[几〇零一二三四五六七八九十廿卅百千]+|(初?[０１２３４５６７８９]+[-—~～﹣－到至])?初?[０１２３４５６７８９]+)[多]?[日号天])"
        self.DayTime = "(?P<DayTime>(一大?|[昨明])早|早上|[早凌清]晨|[上中下晌正昨明]?午|午[时间后夜]|黄昏|[傍当今昨明夜]?晚|晚[间上]|[半子深入今昨明]?夜|夜[半间]|[零子]时|今宵)"
        self.MaybeHour = "(?P<MaybeHour>((?<!\\d)(([01]?\\d|2[0-4])[-—~～﹣－到至])?([01]?\\d|2[0-4])|(?<![〇零一二三四五六七八九十廿卅百千])(((一十?|[〇零十])?[〇零一二三四五六七八九]|一?十|廿|(二十?|廿)[〇零一二三四])[-—~～﹣－到至])?((一十?|[〇零十])?[〇零一二三四五六七八九]|一?十|廿|(二十?|廿)[〇零一二三四])|(?<![０１２３４５６７８９])(([０１]?[０１２３４５６７８９]|２[０１２３４])[-—~～﹣－到至])?[０１２３４５６７８９]+)((个?半)?小时|刻钟|时[许半]?))"
        self.MaybeMinuteOrSecond = "(?P<MaybeMinuteOrSecond>((?<!\\d)(([0-5]?\\d|60)[-—~～﹣－到至])?([0-5]?\\d|60)|(?<![〇零一二三四五六七八九十廿卅百千])((([一二三四五]十?|[〇零十廿卅])?[〇零一二三四五六七八九]|一?十|[廿卅]|六[〇零十])[-—~～﹣－到至])?(([一二三四五]十?|[〇零十廿卅])?[〇零一二三四五六七八九]|一?十|廿|卅|六[〇零十])|(?<![０１２３４５６７８９])(([０１２３４５]?[０１２３４５６７８９]|６０)[-—~～﹣－到至])?([０１２３４５]?[０１２３４５６７８９]|６０))[分秒]钟?)"
        self.VagueTime = "(?P<VagueTime>([今当本这该次此近][年月日]|大?[后前][年天]|[这明昨前][年日天早午晚夜]|[从之以目年日]前|[今过之]后|[未将近]来|过去|[年月][初前中末底]当[今前天下时]|[方刚]才|该天|([这近前上下后过]|(过去|[未将近]来|不远)的)(个[把吧]|[几一二三四五六七八九]*十?)([年天日]|个?月|季度)|[近初前中后末晚早]+期|来[年日时]|[那即]时|(之?前)?不久|([这近前过]|过去|[未将近]来|不远)的)一段(日子|[时期]间)|前一阵子|去年|[如现]今|时下|同一?[年月日天时]|昔日|现[今时在]?|新近|眼前|以[前往]|翌[年月日]|这个月|最近)"

        self.groups = ["YYYYMMDD", "MMDDYYYY", "HHMMSS", "Century", "Decade", "FiveYearPlan", "Year",
                       "MaybeYear", "Season", "YearQuater", "Current", "MonthTime", "Week", "Holidy", "MaybeMonth", "MaybeDay",
                       "DayTime", "MaybeHour", "MaybeMinuteOrSecond", "VagueTime"]

        self.regex = f"{self.YYYYMMDD}|{self.MMDDYYYY}|{self.HHMMSS}|{self.Century}|{self.Decade}|{self.FiveYearPlan}|{self.Year}|{self.MaybeYear}|{self.Season}|{self.YearQuater}|{self.Current}|{self.MonthTime}|{self.Week}|{self.Holidy}|{self.MaybeMonth}|{self.MaybeDay}|{self.DayTime}|{self.MaybeHour}|{self.MaybeMinuteOrSecond}|{self.VagueTime}"

        self.pattern = re.compile(self.regex)

    def get_defined_prompt(self, text: str) -> Optional[str]:
        return None

    def is_year_related(self, text: str) -> bool:
        return False

    def is_month_related(self, text: str) -> bool:
        return False

    def is_day_related(self, text: str) -> bool:
        return False

    def labeling(self, text: str) -> List[str]:
        matcher = self.pattern.finditer(text)

        print(text)

        prompts = []
        for match in matcher:
            for grp, group_name in enumerate(self.groups):
                try:
                    matches = match.group(group_name)
                    if matches is not None:
                        prompt = None
                        if grp == 1:  # "MMDDYYYY"
                            prompt = self.groups[0]
                        elif grp == 3:  # "Century"
                            prompt = "YY00"
                        elif grp == 4:  # "Decade"
                            prompt = "YYY0"
                        elif grp == 5:  # "FiveYearPlan"
                            prompt = "YYY0"
                        elif grp == 6:  # "Year"
                            prompt = "YYYY"
                        elif grp == 7:  # "MaybeYear"
                            prompt = "YYYY?"
                        elif grp == 8:  # "Season"
                            prompt = "XXXX/S"
                        elif grp == 9:  # "YearQuater"
                            prompt = "XXXX/Q"
                        elif grp == 10:  # "Current"
                            prompt = "NOW"
                        elif grp == 11:  # "MonthTime"
                            prompt = "XXXX-XX/T"
                        elif grp == 12:  # "Week"
                            prompt = "XXXX-XX-DD"
                        elif grp == 13:  # "Holidy"
                            prompt = "XXXX-MM-DD"
                        elif grp == 14:  # "MaybeMonth"
                            prompt = "XXXX-MM?"
                        elif grp == 15:  # "MaybeDay"
                            prompt = "XXXX-XX-DD"
                        elif grp == 16:  # "DayTime"
                            prompt = "XXXX-XX-XX/T"
                        elif grp == 17:  # "MaybeHour"
                            prompt = "HH?"
                        elif grp == 18:  # "MaybeMinuteOrSecond"
                            prompt = "MM?"
                        elif grp == 19:  # "VagueTime"
                            prompt = self.get_defined_prompt(matches)
                            if prompt is None:
                                if self.is_year_related(matches):
                                    prompt = "XXXX/?"
                                elif self.is_month_related(matches):
                                    prompt = "XXXX-XX/?"
                                elif self.is_day_related(matches):
                                    prompt = "XXXX-XX-XX/?"
                                else:
                                    prompt = "VagueTime"
                        else:
                            prompt = self.groups[grp]

                        prompts.append(prompt)

                        print(f"匹配:{matches}/{prompt}")

                        break
                except IndexError:
                    pass

        return prompts

    def init(self):
        self.sources = []
        self.goldens = []
        self.sources.append("当地时间1日上午，韩国政府宣布，截至当地时间1日6时，济州航空空难中所有遇难人员的身份均已得到确认，事故善后以及空难原因调查正在展开。2024年12月29日，一架韩国济州航空的客机在位于韩国全罗南道的务安机场着陆时，偏离跑道后撞上机场围墙。除2人获救外，机上其余179人全部遇难，这是在韩国国内发生的伤亡最严重的空难事故。（总台记者 唐鑫）©2025中央广播电视总台版权所有。未经许可，请勿转载使用。")
        # self.sources.append(
        #     "唐太宗李世民（599年1月23日—649年7月10日），唐高祖次子，生于武功（今陕西武功）。 [227] [229]祖籍陇西成纪（今甘肃秦安），一说陇西狄道（今甘肃省临洮县）人，又说钜鹿郡人。唐朝第二位皇帝（626年9月3日 [191]—649年7月10日 [137]在位），政治家、战略家、军事家、书法家、诗人。 [139]\n"
        #     + "李世民少年从军，曾往雁门关解救隋炀帝。首倡晋阳起兵，拜右领军大都督，受封敦煌郡公，领兵攻破长安，拜尚书令、光禄大夫，受封秦国公、赵国公。唐朝建立后，领兵平定薛仁杲、刘武周、窦建德、王世充、刘黑闼等割据势力，为唐朝的建立与统一立下赫赫战功，拜天策上将，封秦王。武德九年六月初四日（626年7月2日），发动“玄武门之变”，诛杀太子李建成和齐王李元吉，被册立为皇太子。八月初九日，唐高祖李渊退位，李世民即皇帝位，年号贞观。\n"
        #     + "贞观二十三年五月己巳日（649年7月10日 [137]），李世民驾崩于含风殿，享年五十二岁，在位二十三年，庙号唐太宗，谥号文皇帝（后加谥文武大圣大广孝皇帝），葬于昭陵。 [224]\n"
        #     + "李世民在位初期，听取群臣意见，虚心纳谏。对内文治天下，厉行节约，劝课农桑，实现休养生息、国泰民安，开创“贞观之治”。对外开疆拓土，攻灭东突厥与薛延陀，征服高昌、龟兹和吐谷浑，重创高句丽。设立安西四镇，与北方地区各民族融洽相处，获得尊号“天可汗”，为唐朝后来一百多年的盛世局面奠定了重要基础。他爱好文学与书法，有诗作与墨宝传世。")

        # self.goldens.append(["YYYYMMDD", "YYYYMMDD", "NOW", "NOW", "NOW", "YYYYMMDD", "YYYYMMDD", 'YYYY',"XXXX-MM?", "XXXX-XX-DD", "YYYYMMDD", "XXXX-MM?", "XXXX-XX-DD", "YYYY", "XXXX-MM?", "YYYYMMDD", "YYYY?", "VagueTime", "YYYY?"])

    def validate(self):
        for i in range(len(self.sources)):
            prompts = self.labeling(self.sources[i])
            # print(f"Prompts: {prompts}")
            # print(f"Expected: {self.goldens[i]}")
            # assert len(self.goldens[i]) == len(prompts)
            # for j in range(len(prompts)):
            #     assert self.goldens[i][j] == prompts[j]

if __name__ == "__main__":
    generator = TempoPromptGenerator()
    generator.init()
    generator.validate()