# from transformers import AutoModelForCausalLM, AutoTokenizer
from transformers import Qwen2ForCausalLM, Qwen2Tokenizer,Qwen2Model
model_name = "Qwen/Qwen2.5-0.5B-Instruct"

model = Qwen2Model.from_pretrained(
    model_name,
    torch_dtype="auto",
    device_map="auto"
)
tokenizer = Qwen2Tokenizer.from_pretrained(model_name)

# 添加特殊 token
special_tokens = {"additional_special_tokens": ["<|time_s|>", "<|time_e|>"]}
tokenizer.add_special_tokens(special_tokens)

print("Special tokens:", tokenizer.additional_special_tokens)

text_input = "1949年10月1日,毛主席在天安门城楼上宣布中华人民共和国成立了,从1927年南昌起义到1949年中华人民共和国成立，中国共产党领导的人民军队经过长期的革命战争,终于取得了全国胜利。第二天,毛主席参加其他庆祝活动"

prompt_text = "<|time_s|>1949年10月1日<|time_e|>,毛主席在天安门城楼上宣布中华人民共和国成立了,从<|time_s|>1927<|time_e|>年南昌起义到<|time_s|>1949年<|time_e|>中华人民共和国成立，中国共产党领导的人民军队经过长期的革命战争,终于取得了全国胜利。<|time_s|>第二天<|time_e|>,毛主席参加其他庆祝活动"

# prompt = "Give me a short introduction to large language model."
messages = [
    {"role": "user", "content": prompt_text}
]
text = tokenizer.apply_chat_template(
    messages,
    tokenize=False,
    add_generation_prompt=False
)
inputs = tokenizer([text], return_tensors="pt").to(model.device)

emb = model.forward(
    **inputs)
# 最后一层的的emb
last_hidden_state = emb.last_hidden_state

print(last_hidden_state.shape)

# 获取特殊 token 的 token ID
time_start_id = tokenizer.convert_tokens_to_ids("<|time_s|>")
time_end_id = tokenizer.convert_tokens_to_ids("<|time_e|>")

# 找到特殊 token 的位置
input_ids = inputs["input_ids"][0]  # 取第 0 个样本的 input_ids
time_start_indices = (input_ids == time_start_id).nonzero(as_tuple=True)[0]
time_end_indices = (input_ids == time_end_id).nonzero(as_tuple=True)[0]

# 提取特殊 token 的 embedding
time_start_embeddings = last_hidden_state[0, time_start_indices]  # <|time_s|> 的 embedding
time_end_embeddings = last_hidden_state[0, time_end_indices]  # <|time_e|> 的 embedding

# 获取特殊 token 之间的 embedding
time_entity_embeddings = []
for start_idx, end_idx in zip(time_start_indices, time_end_indices):
    entity_embedding = last_hidden_state[0, start_idx + 1 : end_idx].mean(dim=0)
    time_entity_embeddings.append(entity_embedding)

print(len(time_entity_embeddings))

